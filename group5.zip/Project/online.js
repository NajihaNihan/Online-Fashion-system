const wrapper = document.querySelector('.wrapper');
const loginlink = document.querySelector('.login-link');
const registerLink = document.querySelector('.register-link');
const btPopup = document.queryselector('.btnLogic-popup');
const iconclose = document.queryselector('.icon-close');

registerLink.addEventListener('click', () =>{
    wrapper.classList.add('active');
});

loginLink.addEventListener('click',() => {
    wrapper.classList.remove('active');
});

btnPopup.addEventListener('click',() => {
    wrapper.classList.remove('active');
});

iconclose.addEventListener('click',() => {
    wrapper.classList.add('active');
});

